from fastapi import FastAPI, Depends, HTTPException, Path
from fastapi.responses import FileResponse
from typing import Optional, List
import hashlib, json, os

app = FastAPI(title="MADOC Compliance Suite API")

POLICY_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "policy"))
HASH_FILE = os.path.join(POLICY_DIR, "hashes.json")

def verify_policy_hash(filename: str) -> str:
    hashes = {}
    if os.path.exists(HASH_FILE):
        with open(HASH_FILE) as f:
            hashes = json.load(f)
    path = os.path.join(POLICY_DIR, filename)
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    digest = h.hexdigest()
    if filename in hashes and hashes[filename] != digest:
        raise ValueError("hash mismatch")
    return path

@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.get("/api/policy-documents/{docId}")
def get_policy(docId: str = Path(..., pattern="^(103DOC730|103DOC750)$")):
    mapping = {
        "103DOC730": "730 - Accessible.pdf",
        "103DOC750": "750 - Accessible.pdf",
    }
    filename = mapping.get(docId)
    if not filename:
        raise HTTPException(status_code=404, detail="Not found")
    try:
        path = verify_policy_hash(filename)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Not found")
    except ValueError:
        raise HTTPException(status_code=409, detail="hash mismatch")
    return FileResponse(path, media_type="application/pdf", filename=filename)

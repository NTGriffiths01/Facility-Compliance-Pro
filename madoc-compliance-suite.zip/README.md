# MADOC Compliance Suite

Monorepo scaffold aligned to 103 DOC 730 and 103 DOC 750. Verbatim policy PDFs are stored under `policy/` with SHA-256 integrity.

## Structure
- `policy/` — official PDFs (**verbatim**) and `hashes.json` with SHA-256.
- `services/api/` — FastAPI service that implements the OpenAPI contract.
- `services/web/` — React app skeleton.
- `infra/` — docker-compose and reverse proxy config.
- `.github/workflows/` — CI.

## Guardrails
- Policy files are served **as-is** from `policy/` and hash-checked at runtime.
- JWT (Azure AD) expected via Bearer auth. RS256 validation stubbed; wire JWKS in prod.

## Run locally
```bash
docker compose -f infra/docker-compose.yml up --build
```

## Upload to GitHub
1. Create a new repo (private by default).
2. `git init && git add . && git commit -m "MADOC scaffold"`
3. `git branch -M main`
4. `git remote add origin https://github.com/<you>/<repo>.git`
5. `git push -u origin main`
